const http = require('http');
const express = require('express');
const path = require('path');
const app = express();
const _ = require("lodash");
const { v4: uuid } = require("uuid");
const bodyParser = require('body-parser');


//const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
//app.use(express.json());
app.use(express.text());
app.use(express.json());
app.use(express.static("express"));
// default URL for website
app.use('/', function(req,res){
    res.sendFile(path.join(__dirname+'/express/index.html'));
    //__dirname : It will resolve to your project folder.
  });
const server = http.createServer(app);
const port = 5000;
server.listen(port);
console.debug('Server listening on port ' + port);